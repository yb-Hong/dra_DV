library(dplyr)
library(ggplot2)
library(tidyr)
library(stringr)
library(DT)
library(scales)


data.sales.wkdy <- data.sales.wkdy %>% mutate(weekday = MON_SALE_AMT + TUS_SALE_AMT,
                           hol = SUN_SALE_AMT + SAT_SALE_AMT,
                           w_h = abs(weekday - hol))
data.sales.wkdy <- data.sales.wkdy %>% arrange(desc(w_h))

data.sales.wkdy %>% group_by(BLOCK_CD, SCLS_NM)
